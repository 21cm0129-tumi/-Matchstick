//
//  MatchStickApp.swift
//  MatchStick
//
//  Created by cmStudent on 2021/12/05.
//

import SwiftUI

@main
struct MatchStickApp: App {
    var body: some Scene {
        WindowGroup {
            startgamen()
        }
    }
}
